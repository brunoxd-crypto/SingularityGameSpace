
#!/system/bin/sh
echo "Singularity GameSpace Fusion service running"
