
package com.singularity.gamespace

import android.app.Service
import android.content.Intent
import android.os.IBinder

class HudService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Overlay HUD placeholder
        return START_STICKY
    }
}
