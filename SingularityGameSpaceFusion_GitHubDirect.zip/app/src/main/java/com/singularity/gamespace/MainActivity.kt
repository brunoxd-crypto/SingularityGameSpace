
package com.singularity.gamespace

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    Column {
                        Text("Singularity GameSpace Fusion", style = MaterialTheme.typography.headlineMedium)
                        Button(onClick = {
                            startService(Intent(this@MainActivity, HudService::class.java))
                        }) { Text("Enable HUD") }
                    }
                }
            }
        }
    }
}
