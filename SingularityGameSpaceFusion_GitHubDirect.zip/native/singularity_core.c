
#include <jni.h>
#include <time.h>

JNIEXPORT jint JNICALL
Java_com_singularity_gamespace_Native_getFPS(JNIEnv* env, jobject thiz) {
    return 60;
}
